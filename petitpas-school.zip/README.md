# Petitpas School

Статический сайт для онлайн‑школы французского.
Развёртывание: GitHub Pages / Netlify.

## Быстрый старт
1. Загрузите эти файлы в публичный репозиторий.
2. Включите GitHub Pages: Settings → Pages → Branch: `main`, Folder: `/root`.
3. Откройте `https://<username>.github.io/<repo>/`.

## Замены
- В `/courses.html` замените ссылки `https://gum.co/your-...` на реальные страницы продуктов.
- В формах замените `FORM_ID` (Google Forms) или `formspree.io/f/your-id`.
- Положите свои PDF в `/assets/free/` и обновите ссылки на `/free.html`.
